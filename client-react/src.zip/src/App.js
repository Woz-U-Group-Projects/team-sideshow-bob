import React from "react";
import  Ticket from "./components/Home";
import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <Ticket />
    </div>
  );
}

export default App;
