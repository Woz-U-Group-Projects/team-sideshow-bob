import React from "react";
import axios from "axios";
import '../ticket.min.css'
import Form from 'react-bootstrap/Form'
import Col from 'react-bootstrap/Col'
import Button from 'react-bootstrap/Button'
class Ticket extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            firstName: '',
            lastName: '',
            email: '',
            content: ''
        }
        this.ticketName = React.createRef();
        this.state = { tickets: [] };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.onValueChange = this.onValueChange.bind(this);
    }

    handleChange = event => {
        this.setState({ value: event.target.value });
    }

    handleSubmit = event => {
        alert('Your ticket has been submitted');
        event.preventDefault();
    }

    onValueChange = event => {
        this.setState({
            selectedOption: event.target.value
            
        });
    }

    addTicket = () => {
        let url = "http://localhost:8080/tickets";
        axios.post(url, { firstName: this.ticketName.current.value, lastName: this.ticketName.current.value, email: this.ticketName.current.value, content: this.ticketName.current.value }).then(response => {
            this.ticketName.current.value = "";
            alert('Your ticket has been submitted');
        });
    };

    getData = () => {
        let url = "http://localhost:8080/tickets";

        axios.get(url).then(response => this.setState({ tickets: response.data }));
    };


    render() {
        return (
            <div>
                <form>
                    <Form.Row>
                    <Col>
                    <Form.Control ref={this.ticketName} type="text" name="firstName" placeholder="First Name"/>
                    </Col>
                    <Col>
                    <Form.Control ref={this.ticketName} type="text" name="lastName" placeholder="Last Name"/>
                    </Col>
                    <Col>       
                    <Form.Control ref={this.ticketName} type="text" name="email" placeholder="Email"/>
                    </Col>
                    </Form.Row>

                    <Form.Group value={this.state.value} onChange={this.handleChange} controlId="category">
                    <Form.Label>Select a Category:</Form.Label>
                    <Form.Control as="select">
                    <option>Hardware</option>
                    <option>Software</option>
                    <option>Internet</option>
                    <option>Other</option>
                    </Form.Control>
                    </Form.Group>

                    <Form.Group controlId="content" name="content" ref={this.ticketName}>
                    <Form.Label>Please Describe Your Issue:</Form.Label>
                    <Form.Control as="textarea" rows={3} />
                    </Form.Group>

                    <fieldset>
                    <Form.Label as="legend" column sm={2}>
                    Select the Urgency Level:
                    </Form.Label>
                    <Form.Group>
                    <Col sm={10}>
                    <Form.Check checked={this.state.selectedOption === "Urgent"} onChange={this.onValueChange}
                    type="radio"
                    label="Urgent"
                    name="Urgency"
                    id="Radio1"
                    />
                    <Form.Check checked={this.state.selectedOption === "Normal"} onChange={this.onValueChange}
                    type="radio"
                    label="Normal"
                    name="Urgency"
                    id="Radio2"
                    />
                    <Form.Check checked={this.state.selectedOption === "Low Priority"} onChange={this.onValueChange}
                    type="radio"
                    label="Low Priority"
                    name="Urgency"
                    id="Radio3"
                    />
                    </Col>
                    </Form.Group>
                    </fieldset>

                <Button variant="primary" type="submit" onClick={this.addTicket}>Submit Ticket</Button>
                </form>

                <h3>Pending Tickets</h3>
                <Button variant="primary" type="button" onClick={this.getData}>Show Pending</Button>
                <ul>
                    {this.state.tickets.map(p => (
                        <li key={p.id}>

                            {p.firstName}{p.lastName}
                            {/* {p.firstName} : { p.complete ? "complete" : "not complete" } <button type="button" className="btn btn-success">Complete</button><button type="button" className="btn btn-danger">Delete</button> */}
                        </li>
                    ))}
                </ul>
            </div>
        );
    }
}
export default Ticket;